// app.js - Open-Meteo with: hourly humidity, animated svg icons, geolocation, loader and weekly avg humidity

const searchInput = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");

const currentIcon = document.getElementById("currentIcon");
const animSun = document.getElementById("animSun");
const animRain = document.getElementById("animRain");

const currentTemp = document.getElementById("currentTemp");
const currentCity = document.getElementById("currentCity");
const currentHumidity = document.getElementById("currentHumidity");
const currentWind = document.getElementById("currentWind");
const weeklyScroll = document.getElementById("weeklyScroll");

const loader = document.getElementById("loader");

// Helper: show/hide loader
function showLoader() { loader.classList.remove("hidden"); loader.setAttribute("aria-hidden","false"); }
function hideLoader() { loader.classList.add("hidden"); loader.setAttribute("aria-hidden","true"); }

// Map Open-Meteo weather codes to local image filenames
function codeToImage(code) {
  if (code === 0) return "images/clear.png";
  if ([1,2,3].includes(code)) return "images/clouds.png";
  if ([45,48].includes(code)) return "images/mist.png";
  if ([51,53,55,56,57,61,63,65,66,67,80,81,82].includes(code)) return "images/rain.png";
  if ([71,73,75,77,85,86].includes(code)) return "images/snow.png";
  return "images/clouds.png";
}

// Toggle animated SVGs depending on code (sun for clear, rain for rain)
function toggleAnimatedIcons(code) {
  // hide all
  animSun.classList.add("hidden");
  animRain.classList.add("hidden");
  currentIcon.classList.remove("hidden");

  if (code === 0) {
    animSun.classList.remove("hidden");
    currentIcon.classList.add("hidden");
  } else if ([51,53,55,56,57,61,63,65,80,81,82].some(c => c === code) || [61,63,65].includes(code)) {
    animRain.classList.remove("hidden");
    currentIcon.classList.add("hidden");
  } else {
    // show static icon image
    animSun.classList.add("hidden");
    animRain.classList.add("hidden");
    currentIcon.classList.remove("hidden");
  }
}

// Get short day name
function dayName(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString(undefined, { weekday: "short" });
}

// Geocoding
async function geoLocate(city) {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Geocoding HTTP error");
  const j = await res.json();
  if (!j.results || j.results.length === 0) return null;
  return j.results[0];
}

// Reverse geocode for lat/lon -> nearest place name
async function reverseGeo(lat, lon) {
  const url = `https://geocoding-api.open-meteo.com/v1/reverse?latitude=${lat}&longitude=${lon}&count=1`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Reverse geocoding HTTP error");
  const j = await res.json();
  if (!j.results || j.results.length === 0) return null;
  return j.results[0];
}

// Fetch weather. Request hourly relativehumidity_2m for current humidity calculation.
// Request daily: max/min temps & weathercode; forecast_days=7 ensures 7 days.
async function fetchWeather(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
              `&current_weather=true&hourly=relativehumidity_2m&daily=temperature_2m_max,temperature_2m_min,weathercode&timezone=auto&forecast_days=7`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Weather HTTP error");
  return await res.json();
}

// compute nearest hourly index to current time string in timezone of response
function findNearestHourIndex(hourlyTimes, nowISO) {
  // hourlyTimes contains ISO strings in same timezone (because timezone=auto)
  let nearest = 0;
  let bestDiff = Infinity;
  for (let i = 0; i < hourlyTimes.length; i++) {
    const t = new Date(hourlyTimes[i]).getTime();
    const diff = Math.abs(t - nowISO);
    if (diff < bestDiff) { bestDiff = diff; nearest = i; }
  }
  return nearest;
}

// compute daily average humidity using hourly arrays (hourly.time and hourly.relativehumidity_2m)
function computeDailyAvgHumidity(hourly, targetDateStr) {
  // targetDateStr in 'YYYY-MM-DD' format
  const times = hourly.time;
  const hums = hourly.relativehumidity_2m;
  let sum = 0, count = 0;
  for (let i = 0; i < times.length; i++) {
    if (times[i].startsWith(targetDateStr)) {
      const h = hums[i];
      if (h !== null && h !== undefined) { sum += h; count++; }
    }
  }
  return count > 0 ? Math.round(sum / count) : null;
}

// Render current values
function renderCurrent(displayName, weatherData) {
  const cur = weatherData.current_weather;
  currentTemp.innerText = Math.round(cur.temperature) + "°C";
  currentWind.innerText = (cur.windspeed !== undefined ? cur.windspeed : "--") + " km/h";
  currentCity.innerText = displayName;

  // compute humidity from hourly nearest hour
  const now = new Date();
  // find nearest index from hourly time array (strings)
  if (weatherData.hourly && weatherData.hourly.time && weatherData.hourly.relativehumidity_2m) {
    const idx = findNearestHourIndex(weatherData.hourly.time, now.getTime());
    const hum = weatherData.hourly.relativehumidity_2m[idx];
    currentHumidity.innerText = (hum !== undefined && hum !== null) ? `${Math.round(hum)}%` : "--%";
  } else {
    currentHumidity.innerText = "--%";
  }

  // icon & animated svg toggle
  const code = cur.weathercode;
  toggleAnimatedIcons(code);
  // set fallback static icon src as well
  currentIcon.src = codeToImage(code);
}

// Render weekly with avg humidity under each card
function renderWeekly(daily, hourly) {
  weeklyScroll.innerHTML = "";
  const times = daily.time;
  const maxs  = daily.temperature_2m_max;
  const mins  = daily.temperature_2m_min;
  const codes = daily.weathercode;

  for (let i = 0; i < times.length; i++) {
    const dateStr = times[i]; // YYYY-MM-DD
    const dCard = document.createElement("div");
    dCard.className = "day-card";

    const nameDiv = document.createElement("div");
    nameDiv.className = "d-name";
    nameDiv.innerText = dayName(dateStr);

    const img = document.createElement("img");
    img.className = "d-icon";
    img.src = codeToImage(codes[i]);
    img.alt = "icon";

    // fallback emoji if img fails:
    img.onerror = function () {
      const emoji = (function(code){
        if (code === 0) return "☀️";
        if ([1,2,3].includes(code)) return "🌤️";
        if ([45,48].includes(code)) return "🌫️";
        if ([51,53,55,61,63,65].includes(code)) return "🌧️";
        if ([71,73,75,77].includes(code)) return "❄️";
        return "⛅";
      })(codes[i]);
      const span = document.createElement("div");
      span.style.fontSize = "28px";
      span.style.margin = "6px 0";
      span.innerText = emoji;
      img.replaceWith(span);
    };

    const tempDiv = document.createElement("div");
    tempDiv.className = "d-temp";
    tempDiv.innerText = `${Math.round(maxs[i])}° / ${Math.round(mins[i])}°`;

    const lowDiv = document.createElement("div");
    lowDiv.className = "d-min";
    lowDiv.innerText = "High / Low";

    // compute avg humidity for that day and show it
    let avgHumText = "";
    if (hourly && hourly.time && hourly.relativehumidity_2m) {
      const avgHum = computeDailyAvgHumidity(hourly, dateStr);
      if (avgHum !== null) avgHumText = `${avgHum}% avg`;
    }
    const humDiv = document.createElement("div");
    humDiv.className = "d-hum";
    humDiv.innerText = avgHumText;

    dCard.appendChild(nameDiv);
    dCard.appendChild(img);
    dCard.appendChild(tempDiv);
    dCard.appendChild(lowDiv);
    dCard.appendChild(humDiv);

    weeklyScroll.appendChild(dCard);
  }
}

// Main flow: city -> geocode -> weather -> render
async function checkWeather(city) {
  if (!city || !city.trim()) return;
  try {
    showLoader();

    const geo = await geoLocate(city);
    if (!geo) {
      currentCity.innerText = "City Not Found";
      currentTemp.innerText = "--°C";
      currentHumidity.innerText = "--%";
      currentWind.innerText = "-- km/h";
      weeklyScroll.innerHTML = "";
      currentIcon.src = "images/error.png";
      hideLoader();
      return;
    }

    const lat = geo.latitude;
    const lon = geo.longitude;
    const displayName = `${geo.name}, ${geo.country}`;

    const data = await fetchWeather(lat, lon);

    if (data.current_weather) renderCurrent(displayName, data);
    if (data.daily) renderWeekly(data.daily, data.hourly);

    hideLoader();
  } catch (err) {
    console.error(err);
    currentCity.innerText = "Error fetching weather";
    currentTemp.innerText = "--°C";
    currentHumidity.innerText = "--%";
    currentWind.innerText = "-- km/h";
    weeklyScroll.innerHTML = "";
    currentIcon.src = "images/error.png";
    hideLoader();
  }
}

// Auto-detect geolocation on load
function tryAutoLocation() {
  if (!navigator.geolocation) {
    // fallback default
    checkWeather("Lahore");
    return;
  }
  showLoader();
  navigator.geolocation.getCurrentPosition(async (pos) => {
    try {
      const { latitude, longitude } = pos.coords;
      // reverse-geocode to get place name
      const place = await reverseGeo(latitude, longitude);
      if (place) {
        const lat = place.latitude;
        const lon = place.longitude;
        const displayName = `${place.name}, ${place.country}`;
        const data = await fetchWeather(lat, lon);
        if (data.current_weather) renderCurrent(displayName, data);
        if (data.daily) renderWeekly(data.daily, data.hourly);
      } else {
        checkWeather("Lahore");
      }
    } catch (err) {
      console.error("Auto location error:", err);
      checkWeather("Lahore");
    } finally {
      hideLoader();
    }
  }, (err) => {
    // user denied or error -> fallback
    hideLoader();
    checkWeather("Lahore");
  }, { timeout: 8000, maximumAge: 1000 * 60 * 60 });
}

// Events
searchBtn.addEventListener("click", () => checkWeather(searchInput.value));
searchInput.addEventListener("keyup", (e) => { if (e.key === "Enter") checkWeather(searchInput.value); });

// On load: try geolocation then fallback
tryAutoLocation();
